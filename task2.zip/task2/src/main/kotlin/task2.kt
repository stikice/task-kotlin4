fun main() {
    2.power(4) { a: Int -> println(a) }
}

fun Int.power(p: Int, foo: (Int) -> Unit): Int {
    var product: Int = 1
    for(i in 1..p){
        product*=this
    }
    foo(product)
    return product
}