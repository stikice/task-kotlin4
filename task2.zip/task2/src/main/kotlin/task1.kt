fun main() {
    2.power(4)
}

fun Int.power(p: Int): Int {
    var product: Int = 1
    for(i in 1..p){
        product*=this
    }
    return product
}