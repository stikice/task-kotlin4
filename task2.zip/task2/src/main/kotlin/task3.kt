fun main() {
    2.displayTypeInfo()
    "a".displayTypeInfo()
    true.displayTypeInfo()
    DataType.DoubleType(1.4).displayTypeInfo()
    DataType.UnitType().displayTypeInfo()
}

fun <T> T.displayTypeInfo() {
    when (this) {
        is String -> {
            println("это String")
        }
        is Int -> {
            println("это Int")
        }
        is DataType.DoubleType -> {
            println("это DoubleType со значением ${this.value}")
        }
        is DataType.UnitType -> {
            println("это Unit")
        }
        else -> {
            println("тип у $this неизвестен")
        }
    }
}

sealed class DataType {
    class DoubleType(val value: Double): DataType()
    class UnitType: DataType()
}